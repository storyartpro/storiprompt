import React, { useState, useEffect } from 'react';
import { ExportButton, saveToLocalStorage, loadFromLocalStorage } from '../utils/exportUtils';

const TemplateBuilderPage = () => {
  const [formData, setFormData] = useState({
    role: '',
    context: '',
    taskType: '',
    responseFormat: '',
    constraints: '',
    example: ''
  });

  const [generatedPrompt, setGeneratedPrompt] = useState('');
  const [copied, setCopied] = useState(false);
  
  // Загрузка данных из localStorage при монтировании компонента
  useEffect(() => {
    const savedFormData = loadFromLocalStorage('template_builder_form');
    if (savedFormData) {
      setFormData(savedFormData);
    }
  }, []);
  
  // Сохранение данных в localStorage при изменении формы
  useEffect(() => {
    saveToLocalStorage('template_builder_form', formData);
  }, [formData]);

  // Обновление промпта при изменении полей формы
  useEffect(() => {
    generatePrompt();
  }, [formData]);

  const handleInputChange = (field, value) => {
    setFormData({
      ...formData,
      [field]: value
    });
  };

  const generatePrompt = () => {
    let prompt = '';
    
    // Добавляем роль, если она указана
    if (formData.role) {
      prompt += `Ты — ${formData.role}. `;
    }
    
    // Добавляем контекст, если он указан
    if (formData.context) {
      prompt += `Контекст: ${formData.context}. `;
    }
    
    // Добавляем тип задачи, если он указан
    if (formData.taskType) {
      prompt += `Задача: ${formData.taskType}. `;
    }
    
    // Добавляем формат ответа, если он указан
    if (formData.responseFormat) {
      prompt += `Формат ответа: ${formData.responseFormat}. `;
    }
    
    // Добавляем ограничения, если они указаны
    if (formData.constraints) {
      prompt += `Ограничения: ${formData.constraints}. `;
    }
    
    // Добавляем пример, если он указан
    if (formData.example) {
      prompt += `Пример: ${formData.example}`;
    }
    
    setGeneratedPrompt(prompt);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedPrompt)
      .then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      })
      .catch(err => {
        console.error('Ошибка при копировании: ', err);
      });
  };

  const clearForm = () => {
    setFormData({
      role: '',
      context: '',
      taskType: '',
      responseFormat: '',
      constraints: '',
      example: ''
    });
  };

  const exportToPDF = () => {
    // Здесь будет реализована функция экспорта в PDF
    alert('Функция экспорта в PDF будет реализована в следующей версии');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Шаблонизатор промптов</h1>
        <p className="text-gray-600 mb-6">
          Создавайте эффективные промпты по структуре, заполняя поля ниже.
          Система автоматически сгенерирует промпт на основе введенных данных.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white shadow-md rounded-lg p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Конструктор промпта</h2>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Роль</label>
              <input
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                placeholder="опытный копирайтер"
                value={formData.role}
                onChange={(e) => handleInputChange('role', e.target.value)}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Контекст</label>
              <textarea
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                rows="3"
                placeholder="я готовлю презентацию для потенциальных инвесторов"
                value={formData.context}
                onChange={(e) => handleInputChange('context', e.target.value)}
              ></textarea>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Тип задачи</label>
              <textarea
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                rows="3"
                placeholder="напиши 5 ключевых преимуществ моего продукта"
                value={formData.taskType}
                onChange={(e) => handleInputChange('taskType', e.target.value)}
              ></textarea>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Формат ответа</label>
              <textarea
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                rows="3"
                placeholder="краткие тезисы с пояснениями, не более 50 слов на каждый"
                value={formData.responseFormat}
                onChange={(e) => handleInputChange('responseFormat', e.target.value)}
              ></textarea>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Ограничения</label>
              <textarea
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                rows="3"
                placeholder="без технических деталей, понятно для нетехнических специалистов"
                value={formData.constraints}
                onChange={(e) => handleInputChange('constraints', e.target.value)}
              ></textarea>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Пример</label>
              <textarea
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-500"
                rows="3"
                placeholder="Преимущество 1: Экономия времени. Наш продукт автоматизирует рутинные задачи, сокращая время обработки на 40%."
                value={formData.example}
                onChange={(e) => handleInputChange('example', e.target.value)}
              ></textarea>
            </div>
          </div>
          
          <div className="mt-6 flex flex-wrap gap-3">
            <button
              className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700"
              onClick={generatePrompt}
            >
              Сгенерировать
            </button>
            <button
              className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300"
              onClick={clearForm}
            >
              Очистить
            </button>
          </div>
        </div>
        
        <div className="bg-white shadow-md rounded-lg p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-gray-900">Сгенерированный промпт</h2>
            
            <div className="flex gap-2">
              <ExportButton 
                data={[{prompt: generatedPrompt}]} 
                format="json" 
                filename="generated_prompt.json" 
                label="Экспорт" 
              />
            </div>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-md border border-gray-200 min-h-[300px] mb-4">
            <pre className="whitespace-pre-wrap text-gray-800 font-mono text-sm">
              {generatedPrompt || 'Заполните поля слева для генерации промпта'}
            </pre>
          </div>
          
          <div className="flex flex-wrap gap-3">
            <button
              className={`px-4 py-2 ${copied ? 'bg-green-600' : 'bg-primary-600'} text-white rounded-md hover:bg-primary-700`}
              onClick={copyToClipboard}
              disabled={!generatedPrompt}
            >
              {copied ? 'Скопировано!' : 'Скопировать'}
            </button>
            <button
              className="px-4 py-2 bg-secondary-600 text-white rounded-md hover:bg-secondary-700"
              onClick={exportToPDF}
              disabled={!generatedPrompt}
            >
              Экспорт в PDF
            </button>
          </div>
          
          <div className="mt-6">
            <h3 className="text-sm font-medium text-gray-700 mb-2">Советы по использованию:</h3>
            <ul className="text-sm text-gray-600 space-y-1 list-disc pl-5">
              <li>Укажите конкретную роль для получения более релевантных ответов</li>
              <li>Добавьте контекст, чтобы AI лучше понимал ваши потребности</li>
              <li>Четко формулируйте задачу и желаемый формат ответа</li>
              <li>Используйте ограничения, чтобы избежать нежелательного контента</li>
              <li>Примеры помогают AI лучше понять ваши ожидания</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TemplateBuilderPage;
