import React, { useState } from 'react';

const ExercisesPage = () => {
  const [exercises, setExercises] = useState(Array.from({ length: 31 }, (_, i) => ({
    id: i + 1,
    day: i + 1,
    title: `Упражнение ${i + 1}`,
    description: `Описание упражнения ${i + 1}`,
    status: 'не начато', // 'не начато', 'начато', 'сделано', 'упаковано'
    timeSpent: 0,
    rating: 0,
    reflection: '',
    notes: ''
  })));

  const [filter, setFilter] = useState('all'); // 'all', 'not-started', 'in-progress', 'done', 'packed'
  
  const filteredExercises = exercises.filter(exercise => {
    if (filter === 'all') return true;
    if (filter === 'not-started') return exercise.status === 'не начато';
    if (filter === 'in-progress') return exercise.status === 'начато';
    if (filter === 'done') return exercise.status === 'сделано';
    if (filter === 'packed') return exercise.status === 'упаковано';
    return true;
  });

  const totalTimeSpent = exercises.reduce((sum, exercise) => sum + exercise.timeSpent, 0);
  const completedExercises = exercises.filter(exercise => 
    exercise.status === 'сделано' || exercise.status === 'упаковано'
  ).length;
  const averageRating = exercises
    .filter(exercise => exercise.rating > 0)
    .reduce((sum, exercise) => sum + exercise.rating, 0) / 
    exercises.filter(exercise => exercise.rating > 0).length || 0;

  const handleStatusChange = (id, status) => {
    setExercises(exercises.map(exercise => 
      exercise.id === id ? { ...exercise, status } : exercise
    ));
  };

  const handleTimeChange = (id, time) => {
    setExercises(exercises.map(exercise => 
      exercise.id === id ? { ...exercise, timeSpent: parseInt(time) || 0 } : exercise
    ));
  };

  const handleRatingChange = (id, rating) => {
    setExercises(exercises.map(exercise => 
      exercise.id === id ? { ...exercise, rating: parseInt(rating) || 0 } : exercise
    ));
  };

  const handleReflectionChange = (id, reflection) => {
    setExercises(exercises.map(exercise => 
      exercise.id === id ? { ...exercise, reflection } : exercise
    ));
  };

  const handleNotesChange = (id, notes) => {
    setExercises(exercises.map(exercise => 
      exercise.id === id ? { ...exercise, notes } : exercise
    ));
  };

  const getNextExercise = () => {
    const notStarted = exercises.find(ex => ex.status === 'не начато');
    const inProgress = exercises.find(ex => ex.status === 'начато');
    return notStarted || inProgress || exercises[0];
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">31 день промт-упражнений</h1>
        <p className="text-gray-600 mb-6">
          Ежедневные упражнения для развития навыков создания эффективных промптов.
          Отслеживайте свой прогресс и улучшайте результаты.
        </p>
        
        <div className="flex flex-wrap gap-4 mb-6">
          <button 
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-md ${filter === 'all' ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-800'}`}
          >
            Все
          </button>
          <button 
            onClick={() => setFilter('not-started')}
            className={`px-4 py-2 rounded-md ${filter === 'not-started' ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-800'}`}
          >
            Не начато
          </button>
          <button 
            onClick={() => setFilter('in-progress')}
            className={`px-4 py-2 rounded-md ${filter === 'in-progress' ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-800'}`}
          >
            В процессе
          </button>
          <button 
            onClick={() => setFilter('done')}
            className={`px-4 py-2 rounded-md ${filter === 'done' ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-800'}`}
          >
            Выполнено
          </button>
          <button 
            onClick={() => setFilter('packed')}
            className={`px-4 py-2 rounded-md ${filter === 'packed' ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-800'}`}
          >
            Упаковано
          </button>
        </div>
        
        <div className="flex justify-between items-center mb-6">
          <div className="flex gap-6">
            <div className="text-sm">
              <span className="text-gray-500">Всего времени:</span> 
              <span className="ml-1 font-medium">{totalTimeSpent} мин</span>
            </div>
            <div className="text-sm">
              <span className="text-gray-500">Выполнено:</span> 
              <span className="ml-1 font-medium">{completedExercises}/31</span>
            </div>
            <div className="text-sm">
              <span className="text-gray-500">Средняя оценка:</span> 
              <span className="ml-1 font-medium">{averageRating.toFixed(1)}/5</span>
            </div>
          </div>
          
          <button 
            onClick={() => {
              const next = getNextExercise();
              if (next) {
                // Scroll to the exercise
                document.getElementById(`exercise-${next.id}`).scrollIntoView({ behavior: 'smooth' });
                // Update status if not started
                if (next.status === 'не начато') {
                  handleStatusChange(next.id, 'начато');
                }
              }
            }}
            className="px-4 py-2 bg-secondary-600 text-white rounded-md hover:bg-secondary-700"
          >
            Следующее упражнение дня
          </button>
        </div>
      </div>
      
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                День
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Упражнение
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Статус
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Время (мин)
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Оценка
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Рефлексия
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filteredExercises.map((exercise) => (
              <tr key={exercise.id} id={`exercise-${exercise.id}`}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  День {exercise.day}
                </td>
                <td className="px-6 py-4 text-sm text-gray-500">
                  <div className="font-medium text-gray-900">{exercise.title}</div>
                  <div className="mt-1">{exercise.description}</div>
                  <div className="mt-2">
                    <button 
                      className="text-xs text-primary-600 hover:text-primary-800"
                      onClick={() => {
                        // Toggle notes visibility
                      }}
                    >
                      Заметки
                    </button>
                  </div>
                  <div className="mt-2 hidden">
                    <textarea
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md"
                      rows="2"
                      placeholder="Ваши заметки..."
                      value={exercise.notes}
                      onChange={(e) => handleNotesChange(exercise.id, e.target.value)}
                    ></textarea>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <select
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    value={exercise.status}
                    onChange={(e) => handleStatusChange(exercise.id, e.target.value)}
                  >
                    <option value="не начато">Не начато</option>
                    <option value="начато">Начато</option>
                    <option value="сделано">Сделано</option>
                    <option value="упаковано">Упаковано</option>
                  </select>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <input
                    type="number"
                    min="0"
                    className="block w-20 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    value={exercise.timeSpent}
                    onChange={(e) => handleTimeChange(exercise.id, e.target.value)}
                  />
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  <select
                    className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    value={exercise.rating}
                    onChange={(e) => handleRatingChange(exercise.id, e.target.value)}
                  >
                    <option value="0">-</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                  </select>
                </td>
                <td className="px-6 py-4 text-sm text-gray-500">
                  <textarea
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    rows="3"
                    placeholder="Ваша рефлексия..."
                    value={exercise.reflection}
                    onChange={(e) => handleReflectionChange(exercise.id, e.target.value)}
                  ></textarea>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ExercisesPage;
