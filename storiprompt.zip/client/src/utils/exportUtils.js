import React from 'react';

// Функция для экспорта данных в CSV формат
export const exportToCSV = (data, filename) => {
  if (!data || !data.length) {
    console.error('No data to export');
    return;
  }

  // Получаем заголовки из первого объекта
  const headers = Object.keys(data[0]);
  
  // Создаем строку заголовков
  let csvContent = headers.join(',') + '\n';
  
  // Добавляем строки данных
  data.forEach(item => {
    const row = headers.map(header => {
      let cell = item[header];
      
      // Обработка массивов (например, теги)
      if (Array.isArray(cell)) {
        cell = '"' + cell.join(';') + '"';
      } 
      // Обработка строк с запятыми
      else if (typeof cell === 'string' && (cell.includes(',') || cell.includes('"') || cell.includes('\n'))) {
        cell = '"' + cell.replace(/"/g, '""') + '"';
      }
      // Обработка undefined и null
      else if (cell === undefined || cell === null) {
        cell = '';
      }
      
      return cell;
    }).join(',');
    
    csvContent += row + '\n';
  });
  
  // Создаем Blob и ссылку для скачивания
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  
  // Создаем временную ссылку для скачивания
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename || 'export.csv');
  link.style.visibility = 'hidden';
  
  // Добавляем ссылку в DOM, кликаем по ней и удаляем
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

// Функция для экспорта данных в JSON формат
export const exportToJSON = (data, filename) => {
  if (!data) {
    console.error('No data to export');
    return;
  }
  
  // Преобразуем данные в JSON строку
  const jsonString = JSON.stringify(data, null, 2);
  
  // Создаем Blob и ссылку для скачивания
  const blob = new Blob([jsonString], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  // Создаем временную ссылку для скачивания
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename || 'export.json');
  link.style.visibility = 'hidden';
  
  // Добавляем ссылку в DOM, кликаем по ней и удаляем
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

// Функция для сохранения данных в localStorage
export const saveToLocalStorage = (key, data) => {
  try {
    const serializedData = JSON.stringify(data);
    localStorage.setItem(key, serializedData);
    return true;
  } catch (error) {
    console.error('Error saving to localStorage:', error);
    return false;
  }
};

// Функция для загрузки данных из localStorage
export const loadFromLocalStorage = (key) => {
  try {
    const serializedData = localStorage.getItem(key);
    if (serializedData === null) {
      return undefined;
    }
    return JSON.parse(serializedData);
  } catch (error) {
    console.error('Error loading from localStorage:', error);
    return undefined;
  }
};

// Компонент кнопки экспорта
export const ExportButton = ({ data, format, filename, label }) => {
  const handleExport = () => {
    if (format === 'csv') {
      exportToCSV(data, filename || 'export.csv');
    } else if (format === 'json') {
      exportToJSON(data, filename || 'export.json');
    }
  };

  return (
    <button
      onClick={handleExport}
      className="px-4 py-2 bg-primary-600 text-white rounded-md hover:bg-primary-700"
    >
      {label || `Экспорт в ${format.toUpperCase()}`}
    </button>
  );
};
